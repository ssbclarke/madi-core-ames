import { useState } from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <button className="btn">Hello daisyUI</button>
    </div>
  );
}

export default App;
